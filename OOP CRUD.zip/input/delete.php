<?php 
  class student{ 
      public $localhost ="localhost",$user ="root",$pass ="",$db_name ="ocrud";
      public $con ;
     public function __construct(){
          $this->con = mysqli_connect($this->localhost,
        $this->user,$this->pass,$this->db_name);
     }
    
     public function OnDeleteData($id){
          $del = "DELETE FROM student WHERE id='$id'";
          $ex = mysqli_query($this->con,$del);
          header("location:index.php");
     }
  }
   
  $st = new student();

 // get user id
 if($_GET['user_id']){
    $st->OnDeleteData($_GET['user_id']);
 }
?>