<?php 
  class student{ 
      public $localhost ="localhost",$user ="root",$pass ="",$db_name ="ocrud";
      public $con ;
     public function __construct(){
          $this->con = mysqli_connect($this->localhost,
        $this->user,$this->pass,$this->db_name);
     }
     public function OnUpdate($data,$id){
          $name = $data['name'];
          $email = $data['email'];
          $pass = $data['pass'];
          $in = "UPDATE student SET name='$name',
          email='$email',pass='$pass' WHERE id='$id';
          ";
          $ex = mysqli_query($this->con,$in);
          if($ex){
            header("location:index.php");
          }else{
            echo "<script>alert('data update failed')</script>";
          }
     }

     public function OnSelectData($id){
        $select = "SELECT * FROM student WHERE id='$id'";
        $query = mysqli_query($this->con,$select);
        $row = mysqli_fetch_array($query);
        
        
        return $row ;
     }
  }
   
  $st = new student();

  if(isset($_POST['update'])){
    $st->OnUpdate($_POST,$_GET['user_id']);
  }
 

 // get user id
 if($_GET['user_id']){
   $userData = $st->OnSelectData($_GET['user_id']);
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body>
  <div class="container">
    <div class="row">
        <div class="col-lg-8">
            <h1>Update user data</h1>
        <form method="post">
           <input name="name" value="<?php  echo $userData['name']?>"  placeholder="enter name" class="form-control" type="text">
           <input name="email" value="<?php  echo $userData['email']?>"  placeholder="enter email" class="form-control" type="email">
           <input name="pass" value="<?php  echo $userData['pass']?>"  placeholder="enter password" class="form-control" type="text">
          <button name="update"  class="btn btn-primary">update Data</button>
        </form>
        </div>
    </div>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  
</body>
</html>